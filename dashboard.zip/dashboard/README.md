This Web application guides the user through the steps needed to analyze a time series data and fit the optimal sARIMA model to perform predictions. 
This application has been built using Plotly Dash and Python

Live App link: https://gabria1.pythonanywhere.com/

Supporting article: [available on Medium](https://medium.com/towards-data-science/time-series-data-analysis-with-sarima-and-dash-f4199c3fc092)


![dash_app_step03](https://user-images.githubusercontent.com/57110246/236455995-a98416d9-57f3-4c6e-b41b-0583ba66c86d.gif)
